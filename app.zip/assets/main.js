function select(selector) {
    return document.querySelector(selector) || null;
}
function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.readAsDataURL(input.files[0]);
        return reader;
    }
}
Element.prototype.remove = function () {
    this.parentElement.removeChild(this);
}
NodeList.prototype.remove = HTMLCollection.prototype.remove = function () {
    for (var i = 0, len = this.length; i < len; i++) {
        if (this[i] && this[i].parentElement) {
            this[i].parentElement.removeChild(this[i]);
        }
    }
}

select('input[type="file"]').onchange = function () {
    select("#can").remove();
    reader = readURL(this);
    var canvas = document.createElement('canvas');
    canvas.id = "can";
    select('#img').appendChild(canvas);
    reader.onload = function (e) {
        Caman("#can", e.target.result, function () {
            this.reset();
        });
    };
};
select('#apply').onclick = function () {
    var effect = select('#effect').value;
    if (effect != 'normal') {
        Caman("#can", function () {
            this.reset();
            this[effect]();
            this.render();
        });
    } else {
        Caman("#can", function () {
            this.reset();
            this.render();
        });
    }
};