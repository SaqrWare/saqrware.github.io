# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'untitled.ui'
#
# Created: Mon Mar 23 06:32:22 2015
#      by: PyQt4 UI code generator 4.10.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(424, 359)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Dialog.sizePolicy().hasHeightForWidth())
        Dialog.setSizePolicy(sizePolicy)
        self.widget = QtGui.QWidget(Dialog)
        self.widget.setGeometry(QtCore.QRect(10, 10, 401, 331))
        self.widget.setObjectName(_fromUtf8("widget"))
        self.gridLayout = QtGui.QGridLayout(self.widget)
        self.gridLayout.setMargin(0)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.groupBox = QtGui.QGroupBox(self.widget)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.widget1 = QtGui.QWidget(self.groupBox)
        self.widget1.setGeometry(QtCore.QRect(0, 30, 131, 49))
        self.widget1.setObjectName(_fromUtf8("widget1"))
        self.verticalLayout = QtGui.QVBoxLayout(self.widget1)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.status1 = QtGui.QLabel(self.widget1)
        self.status1.setObjectName(_fromUtf8("status1"))
        self.verticalLayout.addWidget(self.status1)
        self.relay1 = QtGui.QPushButton(self.widget1)
        self.relay1.setObjectName(_fromUtf8("relay1"))
        self.verticalLayout.addWidget(self.relay1)
        self.gridLayout.addWidget(self.groupBox, 0, 0, 1, 1)
        self.groupBox_4 = QtGui.QGroupBox(self.widget)
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.layoutWidget_3 = QtGui.QWidget(self.groupBox_4)
        self.layoutWidget_3.setGeometry(QtCore.QRect(0, 30, 131, 49))
        self.layoutWidget_3.setObjectName(_fromUtf8("layoutWidget_3"))
        self.verticalLayout_4 = QtGui.QVBoxLayout(self.layoutWidget_3)
        self.verticalLayout_4.setMargin(0)
        self.verticalLayout_4.setObjectName(_fromUtf8("verticalLayout_4"))
        self.status2 = QtGui.QLabel(self.layoutWidget_3)
        self.status2.setObjectName(_fromUtf8("status2"))
        self.verticalLayout_4.addWidget(self.status2)
        self.relay2 = QtGui.QPushButton(self.layoutWidget_3)
        self.relay2.setObjectName(_fromUtf8("relay2"))
        self.verticalLayout_4.addWidget(self.relay2)
        self.gridLayout.addWidget(self.groupBox_4, 0, 1, 1, 1)
        self.groupBox_3 = QtGui.QGroupBox(self.widget)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.layoutWidget_2 = QtGui.QWidget(self.groupBox_3)
        self.layoutWidget_2.setGeometry(QtCore.QRect(0, 30, 131, 49))
        self.layoutWidget_2.setObjectName(_fromUtf8("layoutWidget_2"))
        self.verticalLayout_3 = QtGui.QVBoxLayout(self.layoutWidget_2)
        self.verticalLayout_3.setMargin(0)
        self.verticalLayout_3.setObjectName(_fromUtf8("verticalLayout_3"))
        self.status3 = QtGui.QLabel(self.layoutWidget_2)
        self.status3.setObjectName(_fromUtf8("status3"))
        self.verticalLayout_3.addWidget(self.status3)
        self.relay3 = QtGui.QPushButton(self.layoutWidget_2)
        self.relay3.setObjectName(_fromUtf8("relay3"))
        self.verticalLayout_3.addWidget(self.relay3)
        self.gridLayout.addWidget(self.groupBox_3, 1, 0, 1, 1)
        self.groupBox_2 = QtGui.QGroupBox(self.widget)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.layoutWidget = QtGui.QWidget(self.groupBox_2)
        self.layoutWidget.setGeometry(QtCore.QRect(0, 30, 131, 49))
        self.layoutWidget.setObjectName(_fromUtf8("layoutWidget"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.layoutWidget)
        self.verticalLayout_2.setMargin(0)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.status4 = QtGui.QLabel(self.layoutWidget)
        self.status4.setObjectName(_fromUtf8("status4"))
        self.verticalLayout_2.addWidget(self.status4)
        self.relay4 = QtGui.QPushButton(self.layoutWidget)
        self.relay4.setObjectName(_fromUtf8("relay4"))
        self.verticalLayout_2.addWidget(self.relay4)
        self.gridLayout.addWidget(self.groupBox_2, 1, 1, 1, 1)
        self.status1.setBuddy(self.relay1)
        self.status2.setBuddy(self.relay2)
        self.status3.setBuddy(self.relay3)
        self.status4.setBuddy(self.relay4)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
        Dialog.setTabOrder(self.relay1, self.relay2)
        Dialog.setTabOrder(self.relay2, self.relay3)
        Dialog.setTabOrder(self.relay3, self.relay4)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "Control Panel", None))
        self.groupBox.setTitle(_translate("Dialog", "Relay1", None))
        self.status1.setText(_translate("Dialog", "Status: Off", None))
        self.relay1.setText(_translate("Dialog", "On", None))
        self.groupBox_4.setTitle(_translate("Dialog", "Relay1", None))
        self.status2.setText(_translate("Dialog", "Status: Off", None))
        self.relay2.setText(_translate("Dialog", "On", None))
        self.groupBox_3.setTitle(_translate("Dialog", "Relay1", None))
        self.status3.setText(_translate("Dialog", "Status: Off", None))
        self.relay3.setText(_translate("Dialog", "On", None))
        self.groupBox_2.setTitle(_translate("Dialog", "Relay1", None))
        self.status4.setText(_translate("Dialog", "Status: Off", None))
        self.relay4.setText(_translate("Dialog", "On", None))

