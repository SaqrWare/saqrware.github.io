#!/usr/bin/python
from PyQt4.QtCore import *
from PyQt4.QtGui import *
import sys

import mainGUI
class MainDialog(QDialog,mainGUI.Ui_Dialog):
        def __init__(self):
            QDialog.__init__(self)
            self.setupUi(self)

app = QApplication(sys.argv)
hello = MainDialog()
hello.show()
app.exec_()